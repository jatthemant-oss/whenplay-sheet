# WhenPlay Premium — GitHub par upload aur build karne ke steps

Ye guide step-by-step hai. Har step phone/laptop ke browser se ho sakta hai (laptop
mein drag-drop aasan hai, isliye laptop recommended).

---

## 0. Pehle ye samajh lo (2 minute)

- **Purani repo (TuneX) ko chhuna nahi hai.** Wo waise hi rahegi. Uska app aur
  uske schedules bilkul safe hain.
- **Nayi repo ka naam:** `whenplay-premium`
- **Naya app id:** `com.whenplay.premium` — iska matlab ye app **purane app ke
  saath, alag icon** ki tarah install hoga. Purana app delete nahi hoga.
- **Wapas jaana ho to:** purana app hi kholo. Naya app uninstall kar do. Bas.
- Build GitHub ke computer par hota hai (GitHub Actions), aapke phone par nahi.
  Har push par naya APK ban jata hai.

---

## 1. Nayi repository banao

1. Browser mein kholo: **https://github.com/new**
2. **Repository name:** `whenplay-premium`
3. **Description:** `WhenPlay — Sheet (UI 8) premium build`
4. **Private** select karo (recommended). Public rakhna ho to bhi chalega, lekin
   keystore kabhi public repo mein na daalo.
5. **Add a README file** — tick **mat** karo (khaali repo chahiye).
6. **Create repository** dabao.

Ab aapke paas ek khaali repo khulegi. Us page par ek link dikhega:
`uploading an existing file` — wahi use karenge.

---

## 2. Files upload karo (sabse aasan tareeka: folder drag-drop)

1. Apne computer par `WhenPlay-Premium-v89.zip` ko **unzip** karo.
2. Unzip karne par ek folder milega: `whenplay-premium` — uske **andar** ye cheezein hain:
   ```
   .github/        app/        build.gradle
   .gitignore      settings.gradle
   gradle.properties  README.md  CHANGES-v89.md  GitHub-Steps.md
   ```
3. Repo page par **Add file → Upload files** kholo.
4. File manager se **andar ka saara content** select karke browser mein drag karo.
   - Zyada aasan: `whenplay-premium` folder ko hi drag karo, GitHub khud files
     andar daal deta hai.
   - **Dhyan:** `whenplay-premium` folder ke andar wala `app` folder hi chahiye,
     `app/app` jaisi galti na ho. Upload hone ke baad repo mein `app/build.gradle`
     dikhna chahiye.
5. Neeche **Commit changes** dabao.
6. `.github` folder (hidden) upload mein chhoot sakta hai. Uske liye **Step 3** karo.

---

## 3. Build file alag se banao (zaroori)

GitHub ka build chalane wala file `.github/workflows/build.yml` hai. Agar upload
mein wo chhoot gaya, to:

1. Repo mein **Add file → Create new file** dabao.
2. File name box mein poora path type karo:
   ```
   .github/workflows/build.yml
   ```
   (`/` type karte hi GitHub folder bana deta hai.)
3. Neeche wala content paste karo:

```yaml
name: Build WhenPlay Premium APK

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    permissions:
      contents: read
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 17
      - uses: android-actions/setup-android@v3
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: 8.5
      - name: Restore signing key
        env:
          KS: ${{ secrets.KEYSTORE_BASE64 }}
        run: |
          if [ -n "$KS" ]; then echo "$KS" | base64 -d > app/tunex.keystore; fi
      - name: Build debug APK
        run: gradle assembleDebug --no-daemon
      - name: Name the APK
        run: |
          mkdir -p out
          cp app/build/outputs/apk/debug/*.apk "out/WhenPlay-Premium-v${{ github.run_number }}.apk"
      - uses: actions/upload-artifact@v4
        with:
          name: WhenPlay-Premium-APK
          path: out/*.apk
          retention-days: 90
```

4. **Commit changes** dabao.

---

## 4. Signing key (ek baar, 3 minute — recommended)

Iske bina bhi build chalega, lekin **har build ka signature alag** hoga, to naya
APK purane ke upar install nahi hoga (uninstall karna padega). Ek baar set kar lo,
phir hamesha same key rahegi.

**Aapke paas purani repo ki key hai** (`app/tunex.keystore`), wahi reuse karenge.

1. Purani repo kholo → `app/tunex.keystore` → **Download** (raw file).
2. Us file ko base64 text mein badlo:
   - **Windows PowerShell:**
     ```powershell
     [Convert]::ToBase64String([IO.File]::ReadAllBytes("$HOME\Downloads\tunex.keystore")) | Set-Clipboard
     ```
   - **Mac / Linux:**
     ```bash
     base64 -i ~/Downloads/tunex.keystore | tr -d '\n' | pbcopy
     ```
3. Nayi repo → **Settings → Secrets and variables → Actions → New repository secret**
4. **Name:** `KEYSTORE_BASE64`
5. **Secret:** jo base64 text copy hua tha, wo paste karo → **Add secret**

Bas. Ab har build same key se sign hoga.

> Aasan shortcut (agar base64 jhanjhat nahi chahiye): `tunex.keystore` file ko
> seedha repo mein `app/tunex.keystore` par upload kar do. Build chalega. Lekin
> repo **private** rakhna, warna key public ho jayegi.

---

## 5. Build chalao

1. Repo mein **Actions** tab kholo.
2. Pehli baar "I understand my workflows, go ahead and enable them" aaye to dabao.
3. Left side **Build WhenPlay Premium APK** select karo.
4. Right side **Run workflow → Run workflow** dabao.
5. 3–6 minute wait karo. Page refresh karte raho.
6. Green tick ✔ = build ban gaya. Red ✖ = fail (Step 7 dekho).

Aage se har commit/push par build khud chalega (workflow_dispatch ke saath push
bhi on hai).

---

## 6. APK download aur install

1. Actions → newest run (green tick) par click.
2. Neeche **Artifacts** section → **WhenPlay-Premium-APK** download karo (zip).
3. Phone par zip unzip karo → `WhenPlay-Premium-v89.apk` milega.
4. APK par tap → "Install unknown apps" allow karo (Settings se) → **Install**.
5. Home screen par naya icon: **WhenPlay Premium**. Purana WhenPlay/TuneX alag
   hi rahega.

---

## 7. Build fail ho to (common causes)

| Error | Matlab | Fix |
|---|---|---|
| `SDK location not found` | `local.properties` missing | `.gitignore` mein hai, sahi hai — workflow `setup-android` khud handle karta hai. Ye error aaye to `android-actions/setup-android@v3` step check karo |
| `Keystore file not found` | keystore secret galat | Step 4 dobara karo, ya `app/tunex.keystore` upload karo |
| `Unsupported class file major version` | Java version galat | workflow mein `java-version: 17` hona chahiye |
| `Could not resolve com.android.tools.build` | network/rate limit | 5 min baad **Re-run jobs** |
| `AAPT: error: attribute ... not found` | layout mein typo | run kholo → failing step → last 20 lines padho, mujhe bhej do |

Run ke andar har step ka log hota hai — red step par click karke last lines copy
kar lo.

---

## 8. Aage koi change karna ho

1. Repo mein file kholo (jaise `app/src/main/res/values/colors.xml`).
2. Pencil (Edit) icon → change karo → **Commit changes**.
3. Actions mein build khud chalega, 4–6 min mein naya APK.

Version badalna ho to `app/build.gradle` mein `versionName` change karo —
`versionCode` khud GitHub run number se badhta hai, isliye har build purane ke
upar install ho jata hai.

---

## 9. Purane TuneX par wapas jaana

Kuch karne ki zaroorat nahi:

- Purani repo waisi hi hai, purana app phone mein waisa hi hai.
- Naya app alag package (`com.whenplay.premium`) hai, isliye purane app ka data
  aur schedules ko chhua nahi.
- Purana experience chahiye → purana app icon kholo, ya naya app uninstall kar do.

---

## 10. Repo mein kya-kya hai (file list)

| Path | Kya hai |
|---|---|
| `.github/workflows/build.yml` | GitHub build (APK banata hai) |
| `.gitignore` | build folder ignore |
| `build.gradle` | root gradle (Android plugin 8.2.2, Kotlin 1.9.22) |
| `settings.gradle` | project name `WhenPlayPremium` |
| `gradle.properties` | gradle settings |
| `app/build.gradle` | app id, version, signing |
| `app/src/main/AndroidManifest.xml` | permissions, screens |
| `app/src/main/java/com/tunex/app/*.kt` | 20 Kotlin files (screens, scheduler, player) |
| `app/src/main/res/layout/*.xml` | 12 layouts (edit, main, sheets, rows) |
| `app/src/main/res/drawable/*.xml` | 55 shapes/icons |
| `app/src/main/res/values/*.xml` | colors, theme, strings, dimens |
| `README.md`, `CHANGES-v89.md`, `GitHub-Steps.md` | notes |

Kul **110 files**. Upload ke baad repo mein `app` aur `.github` dono dikhne chahiye.

---

## 11. v89 mein kya badla (short)

- Sheet (UI 8) look, 1:1 — white page, #E61E4D accent, 224dp hero that floods with
  the source colour, big faint source mark, 28dp sheet, rows with › chevrons.
- List screen: "Your schedules" + big UP NEXT card + 62dp thumbnail rows.
- Din ke square buttons ka hard ring hataya — soft tile, off par halka tint, on par accent.
- Do schedule ka time-clash sheet Sheet style mein dobara banaya.
- Delete schedule ke liye naya confirm sheet ("Delete this schedule?" / "Keep it" / "Delete").
- Galat link ka message aur baaki wording simple aur ek jaisi.
- Phone music ka now-playing card accent colour mein (purana green hata).
